import { useState, useMemo } from 'react';
import { store } from '@/lib/store';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';

interface ExamTakingProps {
  examId: string;
  onComplete: () => void;
}

const ExamTaking = ({ examId, onComplete }: ExamTakingProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const exam = store.getExam(examId)!;

  // Shuffle questions once on mount
  const shuffledQuestions = useMemo(() => store.getShuffledQuestions(examId), [examId]);

  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [currentIndex, setCurrentIndex] = useState(0);

  const currentQ = shuffledQuestions[currentIndex];

  const handleAnswer = (value: string) => {
    setAnswers(prev => ({ ...prev, [currentQ.id]: value }));
  };

  const handleSubmit = () => {
    store.submitExam(user!.id, examId, answers);
    toast({ title: 'Exam submitted!', description: 'Your answers have been recorded.' });
    onComplete();
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card px-6 py-4 flex items-center justify-between">
        <div>
          <h1 className="font-display text-xl font-bold">{exam.title}</h1>
          <p className="text-sm text-muted-foreground">Question {currentIndex + 1} of {shuffledQuestions.length}</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">⏱ {exam.duration} min</span>
          <Button variant="destructive" size="sm" onClick={handleSubmit}>Submit Exam</Button>
        </div>
      </header>

      <div className="max-w-3xl mx-auto p-6">
        {/* Question navigation dots */}
        <div className="flex gap-1 flex-wrap mb-6">
          {shuffledQuestions.map((q, i) => (
            <button
              key={q.id}
              onClick={() => setCurrentIndex(i)}
              className={`w-8 h-8 rounded-lg text-xs font-medium transition-colors ${
                i === currentIndex
                  ? 'bg-primary text-primary-foreground'
                  : answers[q.id]
                    ? 'bg-accent/20 text-accent'
                    : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>

        <Card className="animate-fade-in">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">
                Q{currentIndex + 1}. {currentQ.text}
              </CardTitle>
              <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground uppercase">
                {currentQ.type === 'mcq' ? 'MCQ' : 'Short Answer'} · {currentQ.marks}m
              </span>
            </div>
          </CardHeader>
          <CardContent>
            {currentQ.type === 'mcq' && currentQ.options ? (
              <div className="space-y-2">
                {currentQ.options.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => handleAnswer(opt)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors ${
                      answers[currentQ.id] === opt
                        ? 'border-primary bg-primary/5 text-primary font-medium'
                        : 'border-border hover:bg-muted/50'
                    }`}
                  >
                    <span className="mr-2 text-muted-foreground">{String.fromCharCode(65 + i)}.</span>
                    {opt}
                  </button>
                ))}
              </div>
            ) : (
              <Textarea
                value={answers[currentQ.id] || ''}
                onChange={e => handleAnswer(e.target.value)}
                placeholder="Write your answer here..."
                rows={6}
              />
            )}

            <div className="flex justify-between mt-6">
              <Button variant="outline" disabled={currentIndex === 0} onClick={() => setCurrentIndex(i => i - 1)}>
                ← Previous
              </Button>
              {currentIndex < shuffledQuestions.length - 1 ? (
                <Button onClick={() => setCurrentIndex(i => i + 1)}>Next →</Button>
              ) : (
                <Button onClick={handleSubmit}>Submit Exam</Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ExamTaking;
