// In-memory data store for ExamPortal demo

export type Role = 'admin' | 'faculty' | 'student';

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: Role;
}

export interface Question {
  id: string;
  examId: string;
  type: 'mcq' | 'short_answer';
  text: string;
  options?: string[];
  correctAnswer: string;
  marks: number;
}

export interface Exam {
  id: string;
  title: string;
  subject: string;
  duration: number; // minutes
  createdBy: string;
  questions: Question[];
}

export interface StudentMark {
  id: string;
  studentId: string;
  examId: string;
  marks: number;
  totalMarks: number;
  gradedBy: string;
  answers: Record<string, string>;
  shortAnswerMarks?: Record<string, number>;
}

// Seed data
const initialUsers: User[] = [
  { id: '1', name: 'Admin User', email: 'admin@exam.com', password: 'admin123', role: 'admin' },
  { id: '2', name: 'Prof. Sharma', email: 'faculty@exam.com', password: 'faculty123', role: 'faculty' },
  { id: '3', name: 'Rahul Kumar', email: 'student@exam.com', password: 'student123', role: 'student' },
  { id: '4', name: 'Priya Singh', email: 'priya@exam.com', password: 'student123', role: 'student' },
  { id: '5', name: 'Prof. Verma', email: 'faculty2@exam.com', password: 'faculty123', role: 'faculty' },
];

const initialExams: Exam[] = [
  {
    id: 'e1',
    title: 'Mathematics Midterm',
    subject: 'Mathematics',
    duration: 60,
    createdBy: '2',
    questions: [
      { id: 'q1', examId: 'e1', type: 'mcq', text: 'What is the derivative of x²?', options: ['x', '2x', '2', 'x²'], correctAnswer: '2x', marks: 5 },
      { id: 'q2', examId: 'e1', type: 'mcq', text: 'What is ∫2x dx?', options: ['x²', 'x² + C', '2x²', '2x² + C'], correctAnswer: 'x² + C', marks: 5 },
      { id: 'q3', examId: 'e1', type: 'short_answer', text: 'Explain the chain rule of differentiation with an example.', correctAnswer: '', marks: 10 },
      { id: 'q4', examId: 'e1', type: 'mcq', text: 'What is the value of sin(90°)?', options: ['0', '1', '-1', '0.5'], correctAnswer: '1', marks: 5 },
      { id: 'q5', examId: 'e1', type: 'short_answer', text: 'Prove that the sum of angles of a triangle is 180°.', correctAnswer: '', marks: 10 },
    ],
  },
  {
    id: 'e2',
    title: 'Physics Final',
    subject: 'Physics',
    duration: 90,
    createdBy: '5',
    questions: [
      { id: 'q6', examId: 'e2', type: 'mcq', text: 'What is Newton\'s second law?', options: ['F = ma', 'E = mc²', 'F = mv', 'a = v/t'], correctAnswer: 'F = ma', marks: 5 },
      { id: 'q7', examId: 'e2', type: 'mcq', text: 'Unit of force is?', options: ['Joule', 'Newton', 'Watt', 'Pascal'], correctAnswer: 'Newton', marks: 5 },
      { id: 'q8', examId: 'e2', type: 'short_answer', text: 'Explain the law of conservation of energy.', correctAnswer: '', marks: 10 },
    ],
  },
];

const initialMarks: StudentMark[] = [
  { id: 'm1', studentId: '3', examId: 'e1', marks: 28, totalMarks: 35, gradedBy: '2', answers: { q1: '2x', q2: 'x² + C', q3: 'Chain rule explanation...', q4: '1', q5: 'Proof...' } },
  { id: 'm2', studentId: '4', examId: 'e1', marks: 22, totalMarks: 35, gradedBy: '2', answers: { q1: '2x', q2: '2x²', q3: 'Some answer', q4: '0', q5: 'Attempt...' } },
  { id: 'm3', studentId: '3', examId: 'e2', marks: 15, totalMarks: 20, gradedBy: '5', answers: { q6: 'F = ma', q7: 'Newton', q8: 'Energy explanation...' } },
];

// Store class
class Store {
  users: User[] = [...initialUsers];
  exams: Exam[] = [...initialExams];
  marks: StudentMark[] = [...initialMarks];

  // Auth
  login(email: string, password: string): User | null {
    return this.users.find(u => u.email === email && u.password === password) || null;
  }

  register(name: string, email: string, password: string, role: Role): User | null {
    if (this.users.find(u => u.email === email)) return null;
    const user: User = { id: Date.now().toString(), name, email, password, role };
    this.users.push(user);
    return user;
  }

  // Exams
  getExams(): Exam[] { return this.exams; }
  getExam(id: string): Exam | undefined { return this.exams.find(e => e.id === id); }

  addExam(exam: Omit<Exam, 'id'>): Exam {
    const newExam = { ...exam, id: 'e' + Date.now() };
    this.exams.push(newExam);
    return newExam;
  }

  addQuestion(examId: string, question: Omit<Question, 'id' | 'examId'>): Question | null {
    const exam = this.getExam(examId);
    if (!exam) return null;
    const q: Question = { ...question, id: 'q' + Date.now(), examId };
    exam.questions.push(q);
    return q;
  }

  // Shuffle questions for an exam
  getShuffledQuestions(examId: string): Question[] {
    const exam = this.getExam(examId);
    if (!exam) return [];
    const questions = [...exam.questions];
    for (let i = questions.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [questions[i], questions[j]] = [questions[j], questions[i]];
    }
    return questions;
  }

  // Marks
  getStudentMarks(studentId: string): StudentMark[] {
    return this.marks.filter(m => m.studentId === studentId);
  }

  getExamSubmissions(examId: string): (StudentMark & { studentName: string })[] {
    return this.marks
      .filter(m => m.examId === examId)
      .map(m => ({ ...m, studentName: this.users.find(u => u.id === m.studentId)?.name || 'Unknown' }));
  }

  submitExam(studentId: string, examId: string, answers: Record<string, string>): StudentMark {
    const exam = this.getExam(examId)!;
    // Auto-grade MCQs
    let marks = 0;
    const totalMarks = exam.questions.reduce((sum, q) => sum + q.marks, 0);
    exam.questions.forEach(q => {
      if (q.type === 'mcq' && answers[q.id] === q.correctAnswer) {
        marks += q.marks;
      }
    });

    const submission: StudentMark = {
      id: 'm' + Date.now(),
      studentId,
      examId,
      marks,
      totalMarks,
      gradedBy: '',
      answers,
    };
    this.marks.push(submission);
    return submission;
  }

  updateShortAnswerMark(markId: string, questionId: string, score: number, gradedBy: string) {
    const mark = this.marks.find(m => m.id === markId);
    if (!mark) return;
    if (!mark.shortAnswerMarks) mark.shortAnswerMarks = {};
    const prevScore = mark.shortAnswerMarks[questionId] || 0;
    mark.shortAnswerMarks[questionId] = score;
    mark.marks = mark.marks - prevScore + score;
    mark.gradedBy = gradedBy;
  }

  getStudents(): User[] { return this.users.filter(u => u.role === 'student'); }
  getFaculty(): User[] { return this.users.filter(u => u.role === 'faculty'); }
}

export const store = new Store();
