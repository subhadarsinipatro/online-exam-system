import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ClipboardList } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(email, password)) {
      navigate('/dashboard');
    } else {
      toast({ title: 'Error', description: 'Invalid credentials', variant: 'destructive' });
    }
  };

  const fillDemo = (role: 'admin' | 'faculty' | 'student') => {
    const creds = { admin: ['admin@exam.com', 'admin123'], faculty: ['faculty@exam.com', 'faculty123'], student: ['student@exam.com', 'student123'] };
    setEmail(creds[role][0]);
    setPassword(creds[role][1]);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md animate-fade-in shadow-lg">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto w-12 h-12 rounded-xl bg-primary flex items-center justify-center mb-2">
            <ClipboardList className="w-6 h-6 text-primary-foreground" />
          </div>
          <CardTitle className="font-display text-2xl">ExamPortal</CardTitle>
          <CardDescription>Sign in to continue</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Email</label>
              <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" type="email" required />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Password</label>
              <Input value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" type="password" required />
            </div>
            <Button type="submit" className="w-full">Sign In</Button>
          </form>
          <div className="mt-4 text-center text-sm text-muted-foreground">
            Don't have an account? <Link to="/register" className="text-primary font-medium hover:underline">Register here</Link>
          </div>
          <div className="mt-4 p-3 rounded-lg bg-muted text-center space-y-1">
            <p className="text-xs font-semibold text-muted-foreground">Demo credentials</p>
            <div className="flex gap-2 justify-center flex-wrap">
              {(['admin', 'faculty', 'student'] as const).map(r => (
                <button key={r} onClick={() => fillDemo(r)} className="text-xs px-2 py-1 rounded bg-primary/10 text-primary hover:bg-primary/20 transition capitalize">{r}</button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;
