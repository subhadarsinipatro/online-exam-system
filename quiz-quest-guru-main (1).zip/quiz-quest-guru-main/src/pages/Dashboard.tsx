import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';
import AdminDashboard from '@/components/dashboard/AdminDashboard';
import FacultyDashboard from '@/components/dashboard/FacultyDashboard';
import StudentDashboard from '@/components/dashboard/StudentDashboard';

const Dashboard = () => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;

  return (
    <div className="min-h-screen bg-background">
      {user.role === 'admin' && <AdminDashboard />}
      {user.role === 'faculty' && <FacultyDashboard />}
      {user.role === 'student' && <StudentDashboard />}
    </div>
  );
};

export default Dashboard;
